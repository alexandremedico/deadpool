document.querySelector('#A').addEventListener('click', function(clickedElement) {
  alert("Deadpool anti-héros Marvel");
    let click = clickedElement.target;
      if(click.id == "A") {
        document.querySelector('#A').style.opacity = '1';
        document.querySelector('#B').style.opacity = '0.5';
        document.querySelector('#C').style.opacity = '0.5';
      }
})

document.querySelector('#B').addEventListener('click', function(clickedElement) {
  alert("Vanessa est la copine de Deadpool");
    let click = clickedElement.target;
      if(click.id == "B") {
        document.querySelector('#A').style.opacity = '0.5';
        document.querySelector('#B').style.opacity = '1';
        document.querySelector('#C').style.opacity = '0.5';
  }
})

document.querySelector('#C').addEventListener('click', function(clickedElement) {
  alert("Dopinder est le taxi personnel de Deadpool");
    let click = clickedElement.target;
      if(click.id == "C") {
        document.querySelector('#A').style.opacity = '0.5';
        document.querySelector('#B').style.opacity = '0.5';
        document.querySelector('#C').style.opacity = '1';
  }
})

document.querySelector('body').addEventListener('click', function(clickedElement) {
    let click = clickedElement.target;
      if(click.id != "A" && click.id != "B" && click.id != "C") {
        document.querySelector('#A').style.opacity = '1';
        document.querySelector('#B').style.opacity = '1';
        document.querySelector('#C').style.opacity = '1';
    }
})
let prevScrollpos = window.pageYOffset;
window.onscroll = function() {
let currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "5vh";
  } else {
    document.getElementById("navbar").style.top = "-50px";
  }
  prevScrollpos = currentScrollPos;
}
